#!/bin/bash

java -cp "src" Main
